import { loadSettings, saveSettings } from './lib/settings.js';
import { Connection } from './lib/connection.js';
import { PollingConnection } from './lib/polling.js';
import {
  durationText,
  escapeHtml as esc,
  formatChange,
  formatCount,
  formatMc,
  formatMove,
  formatRate,
  TOKEN_STATUS,
  heatClass,
  hostOf,
  httpBase,
  isLocalAddress,
  isValidServerUrl,
  permissionOrigins,
  randomHex,
  socketUrl,
  splitWords,
  timeAgo,
  TOKEN_SITES,
  tokenSite,
  tokenUrl,
  windowLabel,
  windowPhrase,
  xSearchUrl,
} from './lib/format.js';

const $ = (sel) => document.querySelector(sel);
const els = {
  status: $('#status'),
  statusText: $('#status-text'),
  windows: $('#windows'),
  sorts: $('#sorts'),
  filter: $('#filter'),
  summary: $('#summary'),
  notice: $('#notice'),
  words: $('#words'),
  empty: $('#empty'),
  listWrap: $('#list-wrap'),
  feed: $('#feed'),
  feedToggle: $('#feed-toggle'),
  feedRate: $('#feed-rate'),
  feedList: $('#feed-list'),
  settings: $('#settings'),
  serverForm: $('#server-form'),
  serverUrl: $('#server-url'),
  serverState: $('#server-state'),
  holderBody: $('#holder-body'),
  alertsEnabled: $('#alerts-enabled'),
  alertThreshold: $('#alert-threshold'),
  alertsLock: $('#alerts-lock'),
  watchChips: $('#watch-chips'),
  watchForm: $('#watch-form'),
  watchInput: $('#watch-input'),
  hiddenChips: $('#hidden-chips'),
  toast: $('#toast'),
};

const reduceMotion = matchMedia('(prefers-reduced-motion: reduce)').matches;
const FEED_MAX = 40;
const ROWS_MAX = 50;

const state = {
  settings: null,
  conn: null,
  connState: 'connecting',
  server: null,
  holderMode: false,
  holder: null,
  windows: [5, 15, 60],
  freeWindows: [60],
  allowed: [5, 15, 60],
  tier: 'free',
  alerts: false,
  keyStatus: 'none',
  wallet: null,
  window: 60,
  pendingWindow: null,
  snapshot: null,
  query: '',
  expanded: null,
  details: new Map(),
  detailsAt: new Map(),
  rows: new Map(),
  lastCounts: new Map(),
  feed: [],
  feedNeedsHighlight: false,
  verify: null,
  verifyTimer: null,
  noticeKind: null,
  failedOnce: false,
  httpProbe: null,
  probeAt: 0,
  keyNoticeShown: false,
  focusWord: null,
  toastTimer: null,
};

init();

async function init() {
  state.settings = await loadSettings();
  state.window = state.settings.window;
  setFeedOpen(state.settings.feedOpen, false);
  els.filter.value = '';
  $('#version').textContent = `Version ${chrome.runtime.getManifest().version}.`;
  bindUi();
  renderControls();
  renderSummary();
  showEmpty('connecting');

  startTransport('ws');
  if (!state.settings.helpSeen) openHelp();

  chrome.storage.onChanged.addListener(onStorageChanged);
  const { focusWord, pendingVerify } = await chrome.storage.local.get(['focusWord', 'pendingVerify']);
  state.focusWord = focusWord || null;
  if (pendingVerify && pendingVerify.until > Date.now()) {
    state.verify = pendingVerify;
    pollClaim();
  }
  panelSeen();
  document.addEventListener('visibilitychange', () => {
    if (document.visibilityState === 'visible') panelSeen();
  });
  setInterval(tick, 5000);
}

function panelSeen() {
  chrome.runtime.sendMessage({ type: 'panel-opened' }).catch(() => {});
}

// 'ws' streams over a WebSocket. 'http' polls the same data over plain HTTP,
// for browsers that block the WebSocket but let ordinary requests through.
function startTransport(kind) {
  state.conn?.stop();
  state.transport = kind;
  const common = {
    hello: () => ({ key: state.settings.accessKey || undefined, window: state.window, feed: true }),
    onMessage,
    onState,
  };
  state.conn =
    kind === 'http'
      ? new PollingConnection({ base: httpBase(state.settings.serverUrl), ...common })
      : new Connection({ url: socketUrl(state.settings.serverUrl), ...common });
  state.conn.start();
}

// ---------------------------------------------------------------------------
// Server messages

function renderStatus() {
  const s = state.connState;
  els.status.dataset.state = s;
  els.statusText.textContent = s === 'open' ? (state.demo ? 'Demo' : 'Live') : s === 'connecting' ? 'Connecting' : 'Offline';
  els.status.title = s === 'open' && state.demo ? 'Fake launches from the demo server' : '';
}

function onState(s) {
  state.connState = s;
  renderStatus();
  if (s === 'open') {
    state.failedOnce = false;
    state.httpProbe = null;
    if (state.noticeKind === 'offline') hideNotice();
  } else if (!state.snapshot) {
    if (s === 'offline') state.failedOnce = true;
    showEmpty(state.failedOnce ? 'offline' : 'connecting');
  } else if (s === 'offline') {
    els.words.classList.add('loading');
    showNotice(
      'offline',
      `<p>Lost the connection to ${esc(hostOf(state.settings.serverUrl))}. Moth keeps retrying; the list shows the last numbers it got.<br><button class="btn" type="button" data-act="retry">Retry now</button></p>`,
    );
  }
  if (s === 'offline' && state.transport === 'ws') probeHttp();
  renderServerState();
}

// When the WebSocket fails, check whether plain HTTP gets through. If it does,
// the server is up and the browser (or an antivirus) blocks only the WebSocket,
// so switch to polling over HTTP.
async function probeHttp() {
  if (Date.now() - (state.probeAt || 0) < 10_000) return;
  state.probeAt = Date.now();
  let result = 'fail';
  try {
    const res = await fetch(`${httpBase(state.settings.serverUrl)}/health`, { cache: 'no-store', signal: AbortSignal.timeout(5000) });
    if (res.ok) result = 'ok';
  } catch {
    result = 'fail';
  }
  state.httpProbe = result;
  if (result === 'ok' && state.transport === 'ws' && state.connState !== 'open') startTransport('http');
}

function onMessage(msg) {
  switch (msg.type) {
    case 'welcome':
      return handleWelcome(msg);
    case 'tier':
      applyTier(msg);
      state.window = msg.window;
      renderControls();
      renderHolder();
      renderAlerts();
      return toast(msg.tier === 'pro' ? 'Holder access unlocked.' : 'Holder access ended: the wallet no longer holds enough.');
    case 'snapshot':
      return handleSnapshot(msg);
    case 'launch':
      return addLaunch(msg, true);
    case 'word':
      return handleWord(msg);
    case 'error':
      return handleError(msg);
    default:
      return undefined;
  }
}

function applyTier(msg) {
  state.tier = msg.tier;
  state.allowed = msg.allowed || state.allowed;
  state.alerts = Boolean(msg.alerts);
  state.keyStatus = msg.keyStatus || 'none';
  state.wallet = msg.wallet || null;
}

function handleWelcome(msg) {
  state.server = msg.server;
  state.demo = msg.server?.source === 'demo';
  renderStatus();
  if (state.demo && !state.demoNoticeShown) {
    state.demoNoticeShown = true;
    showNotice(
      'demo',
      `<p>These are made-up demo launches, so the tokens don’t exist and have no page. For real launches, close the server window and run <code>start-server.bat</code> (or <code>npm start</code>).</p>${dismissButton()}`,
    );
  } else if (!state.demo && state.noticeKind === 'demo') {
    hideNotice();
  }
  state.holderMode = Boolean(msg.holderMode);
  state.holder = msg.holder;
  state.windows = msg.windows || state.windows;
  state.freeWindows = msg.freeWindows || state.freeWindows;
  applyTier(msg);
  if (msg.window !== state.window) state.lastCounts.clear();
  state.window = msg.window;
  state.pendingWindow = null;
  state.feed = (msg.recent || []).slice(0, FEED_MAX);
  state.feedNeedsHighlight = true;
  renderFeed();
  renderControls();
  renderHolder();
  renderAlerts();
  if (state.holderMode && state.settings.accessKey && state.tier !== 'pro' && !state.keyNoticeShown) {
    state.keyNoticeShown = true;
    const why = keyStatusText(state.keyStatus);
    if (why) {
      showNotice('key', `<p>${esc(why)}<br><button class="btn primary" type="button" data-act="verify">Verify wallet</button></p>${dismissButton()}`);
    }
  }
}

function handleSnapshot(msg) {
  if (msg.window !== state.window) return;
  state.snapshot = msg;
  state.pendingWindow = null;
  if (state.connState === 'open') els.words.classList.remove('loading');
  renderList();
  renderSummary();
  els.feedRate.textContent = `${formatRate(msg.rate)} a minute`;
  if (state.feedNeedsHighlight) {
    state.feedNeedsHighlight = false;
    renderFeed();
  }
  if (state.expanded && Date.now() - (state.detailsAt.get(state.expanded) || 0) > 10_000) requestWord(state.expanded);
  if (state.focusWord) focusOn(state.focusWord);
}

function handleWord(msg) {
  state.details.set(msg.word, msg);
  if (msg.word === state.expanded) renderDetail(msg);
}

function handleError(msg) {
  if (msg.code !== 'holder_required') return;
  if (state.pendingWindow === msg.window) {
    state.pendingWindow = null;
    state.window = Math.max(...state.allowed);
    els.words.classList.remove('loading');
    renderControls();
  }
  showHolderNotice(msg.window);
}

// ---------------------------------------------------------------------------
// Word list

function visibleItems() {
  const snap = state.snapshot;
  if (!snap) return [];
  const hidden = new Set(state.settings.hidden);
  const q = state.query;
  const items = snap.words.filter((w) => !hidden.has(w.w) && (!q || w.w.includes(q)));
  if (state.settings.sort === 'rising') items.sort((a, b) => b.z - a.z || b.c - a.c);
  else items.sort((a, b) => b.c - a.c || b.z - a.z);
  return items.slice(0, ROWS_MAX);
}

function renderList() {
  const snap = state.snapshot;
  if (!snap) return;
  const items = visibleItems();
  if (items.length === 0) {
    showEmpty(state.query ? 'nomatch' : 'nowords');
  } else {
    els.empty.hidden = true;
  }

  const watch = new Set(state.settings.watchlist);
  const max = Math.max(1, ...items.map((i) => i.c));
  const before = new Map();
  if (!reduceMotion) for (const [w, el] of state.rows) before.set(w, el.getBoundingClientRect().top);

  const keep = new Set();
  let prev = null;
  for (const it of items) {
    let el = state.rows.get(it.w);
    if (!el) {
      el = createRow(it.w);
      state.rows.set(it.w, el);
    }
    updateRow(el, it, max, snap.warm, watch.has(it.w));
    keep.add(it.w);
    const slot = prev ? prev.nextSibling : els.words.firstChild;
    if (slot !== el) els.words.insertBefore(el, slot);
    prev = el;
  }
  for (const [w, el] of state.rows) {
    if (keep.has(w)) continue;
    el.remove();
    state.rows.delete(w);
    if (state.expanded === w) state.expanded = null;
  }

  if (!reduceMotion) {
    for (const [w, el] of state.rows) {
      const top = before.get(w);
      if (top === undefined) continue;
      const dy = top - el.getBoundingClientRect().top;
      if (Math.abs(dy) > 1) {
        el.animate([{ transform: `translateY(${dy}px)` }, { transform: 'none' }], { duration: 420, easing: 'cubic-bezier(.2,.7,.2,1)' });
      }
    }
  }
}

function createRow(word) {
  const li = document.createElement('li');
  li.className = 'row';
  li.dataset.word = word;
  li.setAttribute('aria-expanded', 'false');
  li.innerHTML = `
    <div class="row-main" role="button" tabindex="0">
      <span class="word"></span>
      <svg class="spark" viewBox="0 0 46 16" preserveAspectRatio="none" aria-hidden="true"></svg>
      <span class="count"></span>
      <span class="chg"></span>
      <button class="watch" type="button" aria-pressed="false"><svg aria-hidden="true"><use href="#i-star"/></svg></button>
    </div>
    <a class="lead" target="_blank" rel="noopener noreferrer" hidden></a>`;
  li.querySelector('.word').textContent = word;
  return li;
}

// The line under a word: the token with that word people are trading right now.
function updateLead(el, it) {
  const a = el.querySelector('.lead');
  const lead = it.lead;
  if (!lead) {
    a.hidden = true;
    a.dataset.key = '';
    return;
  }
  a.hidden = false;
  const solUsd = state.snapshot?.solUsd;
  const key = [lead.m, lead.mc, lead.ch, lead.st, solUsd, state.settings.tokenSite].join('|');
  if (a.dataset.key === key) return;
  a.dataset.key = key;
  const launch = { mint: lead.m, pool: lead.p };
  const url = tokenUrl(launch, state.settings.tokenSite);
  if (url) a.href = url;
  else a.removeAttribute('href');
  const mc = formatMc(lead.mc, solUsd);
  const move = formatMove(lead.ch);
  const site = url ? ` Opens on ${TOKEN_SITES[tokenSite(launch, state.settings.tokenSite)].label}.` : '';
  a.title = `Most traded token with “${it.w}” right now: ${lead.n}, ${mc} market cap${move.text ? `, ${move.text} in 5 minutes` : ''}. ${TOKEN_STATUS[lead.st] || ''}.${site}`;
  a.innerHTML = `<span class="who"><i class="dot st-${esc(lead.st)}"></i><span class="ln">${esc(lead.n)}</span>${lead.s ? `<span class="ls">$${esc(lead.s)}</span>` : ''}</span><span class="lm">${esc(mc)}</span><span class="lc ${move.tone}">${esc(move.text)}</span>`;
}

function tradeLine(tk, solUsd) {
  const move = formatMove(tk.ch);
  const inner = `<i class="dot st-${esc(tk.st)}"></i><span class="nm">${esc(tk.name)}</span><span class="sym">${tk.symbol ? `$${esc(tk.symbol)}` : ''}</span><span class="mc">${esc(formatMc(tk.mc, solUsd))}</span><span class="chg ${move.tone}">${esc(move.text)}</span>`;
  const title = `${TOKEN_STATUS[tk.st] || ''}. Bonding curve ${tk.pg}% full.`;
  const url = tokenUrl(tk, state.settings.tokenSite);
  return url
    ? `<a href="${esc(url)}" target="_blank" rel="noopener noreferrer" title="${esc(title)}">${inner}</a>`
    : `<span class="tok" title="${esc(title)}">${inner}</span>`;
}

function updateRow(el, it, max, warm, watched) {
  const expanded = state.expanded === it.w;
  el.className = `row ${heatClass(it.z)}${watched ? ' watched' : ''}`;
  el.setAttribute('aria-expanded', String(expanded));
  el.style.setProperty('--pool', `${Math.max(14, Math.round((it.c / max) * 100))}%`);

  const countEl = el.querySelector('.count');
  const text = formatCount(it.c);
  const last = state.lastCounts.get(it.w);
  if (countEl.textContent !== text) {
    countEl.textContent = text;
    if (last !== undefined && it.c > last && !reduceMotion) {
      countEl.classList.remove('bump');
      void countEl.offsetWidth;
      countEl.classList.add('bump');
    }
  }
  state.lastCounts.set(it.w, it.c);

  const change = formatChange(it.c, it.p, warm);
  const chg = el.querySelector('.chg');
  chg.textContent = change.text;
  chg.className = `chg ${change.tone}`;
  chg.title = change.title;

  const spark = el.querySelector('.spark');
  const key = (it.s || []).join(',');
  if (spark.dataset.key !== key) {
    spark.dataset.key = key;
    spark.innerHTML = sparkBars(it.s);
  }

  const star = el.querySelector('.watch');
  star.setAttribute('aria-pressed', String(watched));
  star.setAttribute('aria-label', watched ? `Stop watching ${it.w}` : `Watch ${it.w}`);
  star.title = watched ? 'Watching: click to stop' : 'Watch this word';
  star.querySelector('use').setAttribute('href', watched ? '#i-star-fill' : '#i-star');

  el.querySelector('.row-main').setAttribute('aria-label', `${it.w}, ${text} launches, ${change.text}. ${expanded ? 'Collapse' : 'Show details'}.`);
  updateLead(el, it);
}

function sparkBars(series) {
  if (!series || !series.length) return '';
  const n = series.length;
  const gap = 1;
  const w = (46 - gap * (n - 1)) / n;
  const max = Math.max(1, ...series);
  let out = '';
  series.forEach((v, i) => {
    const h = v ? Math.max(2, (v / max) * 16) : 1;
    const opacity = v ? 0.4 + 0.6 * (i / (n - 1)) : 0.22;
    out += `<rect x="${(i * (w + gap)).toFixed(2)}" y="${(16 - h).toFixed(2)}" width="${w.toFixed(2)}" height="${h.toFixed(2)}" rx="0.8" fill="currentColor" opacity="${opacity.toFixed(2)}"/>`;
  });
  return out;
}

function toggleExpand(word) {
  if (state.expanded === word) return collapse();
  collapse();
  const el = state.rows.get(word);
  if (!el) return;
  state.expanded = word;
  el.setAttribute('aria-expanded', 'true');
  const box = document.createElement('div');
  box.className = 'detail';
  el.append(box);
  const cached = state.details.get(word);
  if (cached && cached.window === state.window) renderDetail(cached);
  else box.innerHTML = '<p class="muted">Loading launches…</p>';
  requestWord(word);
}

function collapse() {
  if (!state.expanded) return;
  const el = state.rows.get(state.expanded);
  if (el) {
    el.setAttribute('aria-expanded', 'false');
    el.querySelector('.detail')?.remove();
  }
  state.expanded = null;
}

function requestWord(word) {
  state.detailsAt.set(word, Date.now());
  state.conn.send({ type: 'word', word, window: state.window });
}

function renderDetail(d) {
  const el = state.rows.get(d.word);
  if (!el) return;
  let box = el.querySelector('.detail');
  if (!box) {
    box = document.createElement('div');
    box.className = 'detail';
    el.append(box);
  }
  const watched = state.settings.watchlist.includes(d.word);
  const pairs = d.related.length
    ? `<h4>Launched together with</h4><div class="pairs">${d.related
        .map(([w, n]) => `<button class="pair" type="button" data-word="${esc(w)}" title="${n} launches use both">${esc(w)}<b>${n}</b></button>`)
        .join('')}</div>`
    : '';
  const trading = Array.isArray(d.trading)
    ? `<h4>Trading now</h4>${
        d.trading.length
          ? `<ol class="trading">${d.trading.map((tk) => `<li>${tradeLine(tk, d.solUsd)}</li>`).join('')}</ol>`
          : '<p class="muted">No token with this word is trading right now.</p>'
      }`
    : '';
  const latest = d.examples.length
    ? `<h4>Latest launches</h4><ol class="latest">${d.examples
        .slice(0, 6)
        .map((ex) => {
          const dot = ex.st ? `<i class="dot st-${esc(ex.st)}" title="${esc(TOKEN_STATUS[ex.st] || '')}"></i>` : '';
          return `<li>${launchLine(ex, dot + esc(ex.name))}</li>`;
        })
        .join('')}</ol>`
    : `<p class="muted">No launches used this word in ${windowPhrase(d.window)}.</p>`;
  const actions = `<div class="actions">
      <a class="link-btn" href="${esc(xSearchUrl(d.word))}" target="_blank" rel="noopener noreferrer"><svg aria-hidden="true"><use href="#i-out"/></svg>Search on X</a>
      <button class="link-btn" type="button" data-act="watch" aria-pressed="${watched}">${watched ? 'Watching' : 'Watch'}</button>
      <button class="link-btn" type="button" data-act="hide">Hide word</button>
    </div>`;
  box.innerHTML = trading + pairs + latest + actions;
}

function focusOn(word) {
  const el = state.rows.get(word);
  state.focusWord = null;
  chrome.storage.local.remove('focusWord');
  if (!el) return toast(`“${word}” isn’t in the list right now.`);
  if (state.expanded !== word) toggleExpand(word);
  el.scrollIntoView({ block: 'nearest', behavior: reduceMotion ? 'auto' : 'smooth' });
}

function openWord(word) {
  if (!state.rows.has(word) && state.query) {
    els.filter.value = '';
    state.query = '';
    renderList();
  }
  if (!state.rows.has(word)) return toast(`“${word}” isn’t in the list right now.`);
  focusOn(word);
}

// ---------------------------------------------------------------------------
// Summary, notices, empty states

function renderSummary() {
  const snap = state.snapshot;
  if (!snap) {
    els.summary.textContent = '';
    return;
  }
  let text = `${formatCount(snap.total)} launches in ${windowPhrase(snap.window)}, about ${formatRate(snap.rate)} a minute.`;
  if (!snap.warm && snap.warmAt) {
    const prev = snap.window === 60 ? 'previous hour' : `previous ${windowLabel(snap.window)}`;
    text += ` Change versus the ${prev} shows in ${durationText(snap.warmAt - Date.now())}.`;
  }
  els.summary.textContent = text;
}

function showEmpty(kind) {
  const host = esc(hostOf(state.settings.serverUrl));
  const moth = '<img src="icons/moth.svg" width="56" height="56" alt="">';
  const retryButtons =
    '<div class="btns"><button class="btn primary" type="button" data-act="retry">Try again</button><button class="btn" type="button" data-act="settings">Open settings</button></div>';
  const html = {
    connecting: `${moth}<h2>Connecting</h2><p>Moth is connecting to ${host}.</p>`,
    offline: `${moth}<h2>Can’t reach the Moth server</h2><p>Nothing answered at ${host}. Start the server (double-click <code>start-demo.bat</code> or run <code>npm run demo</code>), or change the address in Settings.</p>${retryButtons}`,
    nowords: `<h2>No words yet</h2><p>A word shows up here once two new tokens in ${windowPhrase(state.window)} share it.</p>`,
    nomatch: `<h2>No match</h2><p>No word in ${windowPhrase(state.window)} contains “${esc(state.query)}”.</p>`,
  }[kind];
  els.empty.innerHTML = html;
  els.empty.hidden = false;
  if (kind === 'connecting' || kind === 'offline') {
    els.words.replaceChildren();
    state.rows.clear();
    state.expanded = null;
  }
}

function showNotice(kind, html) {
  state.noticeKind = kind;
  els.notice.innerHTML = html;
  els.notice.hidden = false;
}

function hideNotice() {
  state.noticeKind = null;
  els.notice.hidden = true;
  els.notice.replaceChildren();
}

function dismissButton() {
  return '<button class="icon-btn" type="button" data-act="dismiss" aria-label="Dismiss"><svg aria-hidden="true"><use href="#i-close"/></svg></button>';
}

function lockedWindowsText() {
  const locked = state.windows.filter((w) => !state.freeWindows.includes(w)).map(windowLabel);
  if (locked.length === 0) return 'Alerts';
  const list = locked.length === 1 ? locked[0] : `${locked.slice(0, -1).join(', ')} and ${locked.at(-1)}`;
  return `The ${list} window${locked.length > 1 ? 's' : ''} and alerts`;
}

function holderRequirement() {
  const h = state.holder;
  if (!h) return 'holders';
  return `wallets holding at least ${formatCount(h.minBalance)} $${esc(h.symbol)}`;
}

function showHolderNotice(minutes) {
  const label = minutes ? `The ${windowLabel(minutes)} window` : lockedWindowsText();
  showNotice(
    'holder',
    `<p>${esc(label)} ${minutes ? 'is' : 'are'} for ${holderRequirement()}.<br><button class="btn primary" type="button" data-act="verify">Verify wallet</button></p>${dismissButton()}`,
  );
}

function keyStatusText(status) {
  const sym = state.holder ? `$${state.holder.symbol}` : 'the token';
  return (
    {
      expired: 'Your access key expired. Verify your wallet again to renew it.',
      insufficient: `The verified wallet no longer holds enough ${sym}.`,
      invalid: 'That access key doesn’t work on this server.',
      unverified: 'Moth couldn’t check your balance just now. It will try again when you reconnect.',
    }[status] || ''
  );
}

function toast(text) {
  els.toast.textContent = text;
  els.toast.hidden = false;
  clearTimeout(state.toastTimer);
  state.toastTimer = setTimeout(() => {
    els.toast.hidden = true;
  }, 2800);
}

// ---------------------------------------------------------------------------
// Live feed

function setFeedOpen(open, persist = true) {
  els.feed.dataset.open = String(open);
  els.feedToggle.setAttribute('aria-expanded', String(open));
  if (persist) {
    state.settings.feedOpen = open;
    saveSettings({ feedOpen: open });
  }
  if (open) renderFeed();
}

function hotWords() {
  const set = new Set(state.settings.watchlist);
  const snap = state.snapshot;
  if (snap) for (const w of [...snap.words].sort((a, b) => b.c - a.c).slice(0, 10)) set.add(w.w);
  return set;
}

function feedItem(launch, fresh, hot) {
  const li = document.createElement('li');
  li.className = `feed-item${fresh && !reduceMotion ? ' fresh' : ''}`;
  li.innerHTML = launchLine(launch, highlightName(launch.name, launch.words, hot));
  return li;
}

// A launch with a link to its token page, or plain text for made-up demo launches.
function launchLine(launch, nameHtml) {
  const inner = `<span class="nm">${nameHtml}</span><span class="sym">${launch.symbol ? `$${esc(launch.symbol)}` : ''}</span><span class="age" data-t="${launch.t}">${timeAgo(launch.t)}</span>`;
  const url = tokenUrl(launch, state.settings.tokenSite);
  if (!url) return `<span class="tok" title="Demo token: made up, so it has no page anywhere">${inner}</span>`;
  const site = TOKEN_SITES[tokenSite(launch, state.settings.tokenSite)].label;
  return `<a href="${esc(url)}" target="_blank" rel="noopener noreferrer" title="Open ${esc(launch.name)} on ${site}">${inner}</a>`;
}

function renderFeed() {
  if (els.feed.dataset.open !== 'true') return;
  const hot = hotWords();
  els.feedList.replaceChildren(...state.feed.map((l) => feedItem(l, false, hot)));
}

function addLaunch(launch, fresh) {
  state.feed.unshift(launch);
  if (state.feed.length > FEED_MAX) state.feed.length = FEED_MAX;
  if (els.feed.dataset.open !== 'true') return;
  els.feedList.prepend(feedItem(launch, fresh, hotWords()));
  while (els.feedList.children.length > FEED_MAX) els.feedList.lastChild.remove();
}

// Wraps the parts of a name that are hot or watched words in <mark>.
function highlightName(name, words, hot) {
  const lower = name.toLowerCase();
  if (lower.length !== name.length) return esc(name);
  const ranges = [];
  for (const w of words || []) {
    if (!hot.has(w)) continue;
    const i = lower.indexOf(w);
    if (i >= 0) ranges.push([i, i + w.length]);
  }
  if (!ranges.length) return esc(name);
  ranges.sort((a, b) => a[0] - b[0]);
  let out = '';
  let pos = 0;
  for (const [a, b] of ranges) {
    if (a < pos) continue;
    out += esc(name.slice(pos, a)) + `<mark>${esc(name.slice(a, b))}</mark>`;
    pos = b;
  }
  return out + esc(name.slice(pos));
}

function tick() {
  const now = Date.now();
  for (const el of document.querySelectorAll('.age[data-t]')) el.textContent = timeAgo(Number(el.dataset.t), now);
  if (state.snapshot && !state.snapshot.warm) renderSummary();
}

// ---------------------------------------------------------------------------
// Controls

function renderControls() {
  const current = state.pendingWindow ?? state.window;
  els.windows.innerHTML = state.windows
    .map((m) => {
      const locked = !state.allowed.includes(m);
      return `<button type="button" role="radio" aria-checked="${m === current}" data-window="${m}" title="${locked ? 'For holders' : `Words in ${windowPhrase(m)}`}" aria-label="${windowLabel(m)}${locked ? ', for holders' : ''}">${windowLabel(m)}${locked ? '<svg aria-hidden="true"><use href="#i-lock"/></svg>' : ''}</button>`;
    })
    .join('');
  for (const b of els.sorts.querySelectorAll('button')) b.setAttribute('aria-checked', String(b.dataset.sort === state.settings.sort));
}

function chooseWindow(minutes) {
  if (!state.allowed.includes(minutes)) return showHolderNotice(minutes);
  if (state.noticeKind === 'holder') hideNotice();
  if (minutes === state.window && !state.pendingWindow) return;
  state.window = minutes;
  state.pendingWindow = minutes;
  state.lastCounts.clear();
  state.settings.window = minutes;
  saveSettings({ window: minutes });
  els.words.classList.add('loading');
  state.conn.send({ type: 'window', window: minutes });
  renderControls();
  if (state.expanded) requestWord(state.expanded);
}

function chooseSort(sort) {
  if (sort === state.settings.sort) return;
  state.settings.sort = sort;
  saveSettings({ sort });
  renderControls();
  renderList();
  els.listWrap.scrollTop = 0;
}

async function toggleWatch(word, force) {
  const list = new Set(state.settings.watchlist);
  const on = force ?? !list.has(word);
  if (on) list.add(word);
  else list.delete(word);
  state.settings.watchlist = [...list];
  await saveSettings({ watchlist: state.settings.watchlist });
  renderList();
  renderAlerts();
  renderFeed();
  const detail = state.details.get(word);
  if (detail && state.expanded === word) renderDetail(detail);
  if (on) {
    toast(state.alerts && state.settings.alertsEnabled ? `Watching “${word}”. You’ll get an alert when it heats up.` : `Watching “${word}”.`);
    if (!state.alerts && state.holderMode) showHolderNotice(0);
  }
}

async function hideWord(word, hide = true) {
  const set = new Set(state.settings.hidden);
  if (hide) set.add(word);
  else set.delete(word);
  state.settings.hidden = [...set];
  await saveSettings({ hidden: state.settings.hidden });
  if (hide && state.expanded === word) collapse();
  renderList();
  renderHiddenChips();
  if (hide) toast(`“${word}” is hidden. Settings has the list.`);
}

// ---------------------------------------------------------------------------
// Settings sheet

function openSettings() {
  els.serverUrl.value = state.settings.serverUrl;
  renderServerState();
  renderHolder();
  renderAlerts();
  renderHiddenChips();
  renderTokenSite();
  els.settings.hidden = false;
  $('#close-settings').focus();
}

function closeSettings() {
  els.settings.hidden = true;
  $('#open-settings').focus();
}

function openHelp() {
  $('#help').hidden = false;
  $('#close-help').focus();
  if (!state.settings.helpSeen) {
    state.settings.helpSeen = true;
    saveSettings({ helpSeen: true });
  }
}

function closeHelp() {
  $('#help').hidden = true;
  $('#open-help').focus();
}

function renderServerState() {
  if (!els.serverState) return;
  const host = esc(hostOf(state.settings.serverUrl));
  const s = state.connState;
  els.serverState.className = `hint ${s === 'open' ? 'ok' : s === 'offline' ? 'bad' : ''}`;
  els.serverState.innerHTML =
    s === 'open'
      ? `Connected to ${host}${state.server ? `, Moth server ${esc(state.server.version)}` : ''}.${
          state.transport === 'http' ? ' This browser blocks the live WebSocket, so the panel asks the server for updates every 3 seconds instead.' : ''
        }`
      : s === 'offline'
        ? `Can’t reach ${host}. Moth retries on its own.`
        : `Connecting to ${host}…`;
}

function renderHolder() {
  const box = els.holderBody;
  if (!state.server) {
    box.innerHTML = '<p class="hint">Connect to a server to see what holders get.</p>';
    return;
  }
  if (!state.holderMode) {
    box.innerHTML = '<p class="hint">This server is in open mode: every window and alerts are unlocked for everyone.</p>';
    return;
  }
  const h = state.holder;
  if (state.tier === 'pro') {
    box.innerHTML = `<p class="hint ok">Unlocked with wallet ${esc(state.wallet || '')}. Short windows and alerts are on.</p>
      <div class="btns"><button class="btn" type="button" data-act="forget-key">Forget this wallet</button></div>`;
    return;
  }
  if (state.verify) {
    box.innerHTML = `<p class="hint">Finish in the tab that opened: connect your wallet and sign the message. This panel unlocks on its own once you do.</p>
      <div class="btns"><button class="btn" type="button" data-act="reopen-verify">Open the page again</button><button class="btn" type="button" data-act="cancel-verify">Cancel</button></div>`;
    return;
  }
  const status = state.settings.accessKey ? keyStatusText(state.keyStatus) : '';
  box.innerHTML = `<p class="hint">${esc(lockedWindowsText())} are for ${holderRequirement()}. You prove it by signing a message; nothing leaves your wallet.</p>
    ${status ? `<p class="hint bad">${esc(status)}</p>` : ''}
    <div class="btns">
      <button class="btn primary" type="button" data-act="verify">Verify wallet</button>
      <a class="btn" href="${esc(h.buyUrl)}" target="_blank" rel="noopener noreferrer">Get $${esc(h.symbol)}<svg aria-hidden="true"><use href="#i-out"/></svg></a>
    </div>
    <details class="key"><summary>Have an access key?</summary>
      <form class="row-form" id="key-form"><input id="key-input" type="text" placeholder="moth_…" spellcheck="false" autocomplete="off" aria-label="Access key"><button class="btn" type="submit">Use key</button></form>
    </details>`;
}

function renderAlerts() {
  els.alertsEnabled.checked = state.settings.alertsEnabled;
  els.alertThreshold.value = String(state.settings.alertThreshold);
  const locked = Boolean(state.server) && !state.alerts;
  els.alertsLock.hidden = !locked;
  if (locked) {
    els.alertsLock.textContent = `Alerts are for ${state.holder ? `$${state.holder.symbol}` : 'token'} holders. You can still watch words: they get a dot in the list and a highlight in the feed.`;
  }
  els.alertsEnabled.disabled = locked;
  els.alertThreshold.disabled = locked;
  renderChips(els.watchChips, state.settings.watchlist, 'unwatch');
}

function renderTokenSite() {
  $('#token-site').value = TOKEN_SITES[state.settings.tokenSite] ? state.settings.tokenSite : 'gmgn';
}

function renderHiddenChips() {
  renderChips(els.hiddenChips, state.settings.hidden, 'unhide');
}

function renderChips(ul, words, act) {
  ul.innerHTML = words
    .map((w) => `<li class="chip">${esc(w)}<button type="button" data-act="${act}" data-word="${esc(w)}" aria-label="Remove ${esc(w)}"><svg aria-hidden="true"><use href="#i-close"/></svg></button></li>`)
    .join('');
}

async function saveServer(e) {
  e.preventDefault();
  const raw = els.serverUrl.value.trim();
  if (!isValidServerUrl(raw)) {
    els.serverState.className = 'hint bad';
    els.serverState.textContent = 'That doesn’t look like an address. Try https://moth.example.com or localhost:8787.';
    return;
  }
  const url = httpBase(raw);
  // Chrome blocks extensions from reaching this computer or the local network
  // unless they hold a host permission for that address, so ask for it here.
  if (isLocalAddress(url)) {
    let allowed = false;
    try {
      allowed = await chrome.permissions.request({ origins: permissionOrigins(url) });
    } catch {
      allowed = false;
    }
    if (!allowed) {
      els.serverState.className = 'hint bad';
      els.serverState.textContent = 'Moth needs your permission to reach an address on this computer or your network. Press Save again and choose Allow.';
      return;
    }
  }
  state.settings.serverUrl = url;
  await saveSettings({ serverUrl: url });
  els.serverUrl.value = url;
  state.snapshot = null;
  state.server = null;
  state.feed = [];
  state.failedOnce = false;
  state.httpProbe = null;
  state.probeAt = 0;
  renderFeed();
  renderSummary();
  showEmpty('connecting');
  startTransport('ws');
  toast('Server saved.');
}

// ---------------------------------------------------------------------------
// Holder verification: open the server's verify page, then poll for the key.

async function startVerify() {
  if (!state.server) return toast('Connect to a server first.');
  const session = randomHex(16);
  state.verify = { session, until: Date.now() + 10 * 60_000 };
  await chrome.storage.local.set({ pendingVerify: state.verify });
  openVerifyTab();
  renderHolder();
  pollClaim();
}

function openVerifyTab() {
  if (!state.verify) return;
  chrome.tabs.create({ url: `${httpBase(state.settings.serverUrl)}/verify?session=${state.verify.session}` });
}

async function pollClaim() {
  clearTimeout(state.verifyTimer);
  const v = state.verify;
  if (!v) return;
  if (Date.now() > v.until) return cancelVerify();
  try {
    const res = await fetch(`${httpBase(state.settings.serverUrl)}/api/claim?session=${v.session}`, { cache: 'no-store' });
    if (res.ok) {
      const body = await res.json();
      if (body.key) return useKey(body.key, 'Holder access unlocked.');
    }
  } catch {
    /* server unreachable; keep polling */
  }
  if (state.verify === v) state.verifyTimer = setTimeout(pollClaim, 2000);
}

function cancelVerify() {
  state.verify = null;
  clearTimeout(state.verifyTimer);
  chrome.storage.local.remove('pendingVerify');
  renderHolder();
}

async function useKey(key, message) {
  state.verify = null;
  clearTimeout(state.verifyTimer);
  await chrome.storage.local.remove('pendingVerify');
  state.settings.accessKey = key;
  await saveSettings({ accessKey: key });
  state.keyNoticeShown = false;
  if (state.noticeKind === 'holder' || state.noticeKind === 'key') hideNotice();
  state.conn.restart();
  toast(message);
  renderHolder();
}

async function forgetKey() {
  state.settings.accessKey = '';
  await saveSettings({ accessKey: '' });
  state.conn.restart();
  toast('Wallet forgotten.');
}

// ---------------------------------------------------------------------------
// Events

function bindUi() {
  els.windows.addEventListener('click', (e) => {
    const b = e.target.closest('button[data-window]');
    if (b) chooseWindow(Number(b.dataset.window));
  });
  els.sorts.addEventListener('click', (e) => {
    const b = e.target.closest('button[data-sort]');
    if (b) chooseSort(b.dataset.sort);
  });
  for (const group of [els.windows, els.sorts]) {
    group.addEventListener('keydown', (e) => {
      if (e.key !== 'ArrowRight' && e.key !== 'ArrowLeft') return;
      const buttons = [...group.querySelectorAll('button')];
      const i = buttons.indexOf(document.activeElement);
      if (i < 0) return;
      const next = buttons[(i + (e.key === 'ArrowRight' ? 1 : buttons.length - 1)) % buttons.length];
      next.focus();
      next.click();
      e.preventDefault();
    });
  }

  els.filter.addEventListener('input', () => {
    state.query = els.filter.value.trim().toLowerCase().replace(/^[$#]+/, '');
    renderList();
  });

  els.words.addEventListener('click', (e) => {
    const row = e.target.closest('.row');
    if (!row) return;
    const word = row.dataset.word;
    if (e.target.closest('.watch')) {
      e.stopPropagation();
      return toggleWatch(word);
    }
    const pair = e.target.closest('.pair');
    if (pair) return openWord(pair.dataset.word);
    const act = e.target.closest('[data-act]')?.dataset.act;
    if (act === 'watch') return toggleWatch(word);
    if (act === 'hide') return hideWord(word);
    if (e.target.closest('.row-main')) toggleExpand(word);
  });
  els.words.addEventListener('keydown', (e) => {
    if ((e.key === 'Enter' || e.key === ' ') && e.target.classList.contains('row-main')) {
      e.preventDefault();
      toggleExpand(e.target.closest('.row').dataset.word);
    }
  });

  document.addEventListener('click', (e) => {
    const act = e.target.closest('[data-act]')?.dataset.act;
    if (!act || e.target.closest('#words')) return;
    const word = e.target.closest('[data-word]')?.dataset.word;
    switch (act) {
      case 'retry':
        return state.conn.retryNow();
      case 'settings':
        return openSettings();
      case 'dismiss':
        return hideNotice();
      case 'verify':
        if (els.settings.hidden) openSettings();
        return startVerify();
      case 'reopen-verify':
        return openVerifyTab();
      case 'cancel-verify':
        return cancelVerify();
      case 'forget-key':
        return forgetKey();
      case 'unwatch':
        return toggleWatch(word, false);
      case 'unhide':
        return hideWord(word, false);
      default:
        return undefined;
    }
  });

  els.feedToggle.addEventListener('click', () => setFeedOpen(els.feed.dataset.open !== 'true'));

  $('#open-settings').addEventListener('click', openSettings);
  $('#close-settings').addEventListener('click', closeSettings);
  $('#open-help').addEventListener('click', openHelp);
  $('#close-help').addEventListener('click', closeHelp);
  document.addEventListener('keydown', (e) => {
    if (e.key !== 'Escape') return;
    if (!$('#help').hidden) closeHelp();
    else if (!els.settings.hidden) closeSettings();
    else if (state.expanded) collapse();
  });

  els.serverForm.addEventListener('submit', saveServer);
  els.holderBody.addEventListener('submit', (e) => {
    if (e.target.id !== 'key-form') return;
    e.preventDefault();
    const key = $('#key-input').value.trim();
    if (!/^moth_[\w-]+\.[\w-]+$/.test(key)) return toast('Access keys start with moth_ and come from the verify page.');
    useKey(key, 'Key saved. Checking it…');
  });

  $('#token-site').addEventListener('change', (e) => {
    state.settings.tokenSite = e.target.value;
    saveSettings({ tokenSite: e.target.value });
    renderFeed();
    const detail = state.expanded && state.details.get(state.expanded);
    if (detail) renderDetail(detail);
    toast(`Tokens now open on ${TOKEN_SITES[e.target.value].label}.`);
  });

  els.alertsEnabled.addEventListener('change', () => {
    state.settings.alertsEnabled = els.alertsEnabled.checked;
    saveSettings({ alertsEnabled: state.settings.alertsEnabled });
  });
  els.alertThreshold.addEventListener('change', () => {
    const n = Math.min(99, Math.max(2, Math.round(Number(els.alertThreshold.value) || 5)));
    els.alertThreshold.value = String(n);
    state.settings.alertThreshold = n;
    saveSettings({ alertThreshold: n });
  });
  els.watchForm.addEventListener('submit', async (e) => {
    e.preventDefault();
    const words = splitWords(els.watchInput.value);
    if (!words.length) return;
    for (const w of words) await toggleWatch(w, true);
    els.watchInput.value = '';
  });
}

function onStorageChanged(changes, area) {
  if (area !== 'local') return;
  if (changes.focusWord?.newValue) {
    state.focusWord = changes.focusWord.newValue;
    if (state.snapshot) focusOn(state.focusWord);
  }
  let relist = false;
  for (const key of ['watchlist', 'hidden']) {
    if (changes[key] && JSON.stringify(changes[key].newValue) !== JSON.stringify(state.settings[key])) {
      state.settings[key] = changes[key].newValue || [];
      relist = true;
    }
  }
  if (relist) {
    renderList();
    renderAlerts();
    renderHiddenChips();
  }
}

// Handy when debugging the panel from DevTools.
globalThis.moth = { state };
