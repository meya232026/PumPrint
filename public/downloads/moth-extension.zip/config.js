// Where the panel looks for the Moth server until the user changes it in Settings.
// Point this at your deployed server before publishing the extension.
export const DEFAULT_SERVER_URL = 'http://localhost:8787';

export const ALERT_WINDOW_MIN = 15;
