// Background worker: opens the side panel from the toolbar button and checks
// watched words once a minute for desktop alerts.

import { loadSettings } from './lib/settings.js';
import { ALERT_WINDOW_MIN } from './config.js';
import { httpBase, tokenUrl } from './lib/format.js';

const ALARM = 'moth-alerts';
const COOLDOWN_MS = 30 * 60_000;
// A watched word must also be climbing: at least this many times the previous window.
const RISE = 1.5;

chrome.runtime.onInstalled.addListener(setup);
chrome.runtime.onStartup.addListener(setup);

async function setup() {
  await chrome.sidePanel.setPanelBehavior({ openPanelOnActionClick: true }).catch(() => {});
  if (!(await chrome.alarms.get(ALARM))) chrome.alarms.create(ALARM, { delayInMinutes: 0.5, periodInMinutes: 1 });
  await chrome.action.setBadgeBackgroundColor({ color: '#FFB547' });
  await chrome.action.setBadgeTextColor?.({ color: '#1A1638' });
}

chrome.alarms.onAlarm.addListener((alarm) => {
  if (alarm.name === ALARM) checkAlerts().catch(() => {});
});

chrome.runtime.onMessage.addListener((msg, _sender, reply) => {
  if (msg?.type === 'panel-opened') {
    chrome.action.setBadgeText({ text: '' });
    chrome.storage.local.set({ unseenAlerts: 0 });
  } else if (msg?.type === 'check-alerts') {
    checkAlerts().then(reply, () => reply({ ok: false }));
    return true;
  }
  return false;
});

export async function checkAlerts() {
  const s = await loadSettings();
  if (!s.alertsEnabled || s.watchlist.length === 0) return { ok: true, fired: 0 };
  const url = `${httpBase(s.serverUrl)}/api/watch?window=${ALERT_WINDOW_MIN}&words=${encodeURIComponent(s.watchlist.join(','))}`;
  let res;
  try {
    res = await fetch(url, { headers: s.accessKey ? { authorization: `Bearer ${s.accessKey}` } : {}, cache: 'no-store' });
  } catch {
    return { ok: false, reason: 'offline' };
  }
  if (res.status === 402) {
    await chrome.storage.local.set({ alertsBlocked: true });
    return { ok: false, reason: 'holder_required' };
  }
  if (!res.ok) return { ok: false, reason: `http_${res.status}` };
  const data = await res.json();

  const { alertLog = {}, unseenAlerts = 0 } = await chrome.storage.local.get(['alertLog', 'unseenAlerts']);
  const now = Date.now();
  let fired = 0;
  for (const w of data.words || []) {
    const climbing = w.prev === 0 || w.count >= w.prev * RISE;
    if (w.count < s.alertThreshold || !climbing) continue;
    if (now - (alertLog[w.word] || 0) < COOLDOWN_MS) continue;
    alertLog[w.word] = now;
    fired++;
    await notify(w);
  }
  for (const [word, t] of Object.entries(alertLog)) if (now - t > 24 * 60 * 60_000) delete alertLog[word];
  const unseen = unseenAlerts + fired;
  await chrome.storage.local.set({ alertLog, alertsBlocked: false, unseenAlerts: unseen });
  if (fired) await chrome.action.setBadgeText({ text: String(Math.min(unseen, 99)) });
  return { ok: true, fired };
}

async function notify(w) {
  const id = `moth:${w.word}:${Date.now()}`;
  const latest = w.latest ? `Latest: ${w.latest.name}${w.latest.symbol ? ` ($${w.latest.symbol})` : ''}` : '';
  const { tokenSite = 'gmgn' } = await chrome.storage.local.get('tokenSite');
  await chrome.storage.session.set({ [id]: { word: w.word, url: w.latest ? tokenUrl(w.latest, tokenSite) : '' } });
  await chrome.notifications.create(id, {
    type: 'basic',
    iconUrl: 'icons/icon128.png',
    title: `“${w.word}” is heating up`,
    message: `${w.count} new tokens in the last ${ALERT_WINDOW_MIN} minutes${w.prev ? `, up from ${w.prev}` : ''}.`,
    contextMessage: latest,
    priority: 1,
  });
}

chrome.notifications.onClicked.addListener(async (id) => {
  if (!id.startsWith('moth:')) return;
  const stored = (await chrome.storage.session.get(id))[id] || {};
  chrome.notifications.clear(id);
  chrome.storage.session.remove(id);
  if (stored.word) await chrome.storage.local.set({ focusWord: stored.word });
  try {
    const win = await chrome.windows.getLastFocused();
    await chrome.sidePanel.open({ windowId: win.id });
  } catch {
    // Some Chrome versions only open the panel from a direct click; fall back to the token page.
    if (stored.url) chrome.tabs.create({ url: stored.url });
  }
});

chrome.notifications.onClosed.addListener((id) => {
  if (id.startsWith('moth:')) chrome.storage.session.remove(id);
});

// Handy when debugging the worker from DevTools.
globalThis.checkAlerts = checkAlerts;
